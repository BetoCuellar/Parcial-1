import React, { useState } from 'react';
import './Calculadora.css';

const Calculator = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');
  const [info] = useState('Nicolas Cuellar - 2220906');

  const handleNumberClick = (number) => {
    setInput(input + number);
  };

  const handleOperatorClick = (operator) => {
    if (input && !['+', '-', '*', '/'].includes(input.slice(-1))) {
      setInput(input + ' ' + operator + ' ');
    }
  };

  const calculateResult = (expression) => {
    if (!expression) return '';
    try {
      const total = eval(expression.replace(/[^0-9+\-*/. ]/g, ''));
      return total;
    } catch (error) {
      return 'Error';
    }
  };

  const handleSum = () => {
    const trimmedInput = input.trim();
    if (trimmedInput) {
      const result = calculateResult(trimmedInput);
      setResult(result);
      setInput('');
    }
  };

  const handleReset = () => {
    setInput('');
    setResult('');
  };

  return (
    <div className="calculator">
      <div className="screen">{input || result}</div>
      <div className="button-container">
        <button className="number" onClick={() => handleNumberClick('1')}>1</button>
        <button className="number" onClick={() => handleNumberClick('2')}>2</button>
        <button className="number" onClick={() => handleNumberClick('3')}>3</button>
        <button className="operation" onClick={() => handleOperatorClick('+')}>+</button>
        
        <button className="number" onClick={() => handleNumberClick('4')}>4</button>
        <button className="number" onClick={() => handleNumberClick('5')}>5</button>
        <button className="number" onClick={() => handleNumberClick('6')}>6</button>
        <button className="operation" onClick={() => handleOperatorClick('-')}>-</button>
        
        <button className="number" onClick={() => handleNumberClick('7')}>7</button>
        <button className="number" onClick={() => handleNumberClick('8')}>8</button>
        <button className="number" onClick={() => handleNumberClick('9')}>9</button>
        <button className="operation" onClick={() => handleOperatorClick('*')}>*</button>

        <button className="reset" onClick={handleReset}>C</button>
        <button className="number" onClick={() => handleNumberClick('0')}>0</button>
        <button className="operation" onClick={() => handleOperatorClick('/')}>÷</button>
        <button className="operation" onClick={handleSum}>=</button>
      </div>
      <div className="info-container" style={{ padding: '10px', fontSize: '18px', color: 'white' }}>
        {info} {}
      </div>
    </div>
  );
};

export default Calculator;
